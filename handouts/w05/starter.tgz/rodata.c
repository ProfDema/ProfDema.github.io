#include <stdio.h>
#include "rodata.h"

int main(int argc, char **argv) {

    // TODO: Read command line argument

    // TODO: Seek to location of section header start, read address

    // TODO: Either seek to correct header and read it or read array of 16
    
    // TODO: Print address of rodata section and its size
    
    return 0;
}  
