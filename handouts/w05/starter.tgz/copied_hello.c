#include <stdio.h>
#include <string.h>

int main(int argc, char **argv) {
    char buf[15];
    strcpy(buf, "Hello world!");
    printf("%s\n", buf);
    return 0;
}
