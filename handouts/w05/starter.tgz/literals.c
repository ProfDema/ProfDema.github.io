#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {

    // TODO: Read arguments and convert the numeric values
    
    // TODO: Seek to the rodata section and then read it

    // TODO: print the data in the rodata section, with each
    // string on its own line

    return 0;
}
