#include <stdint.h>

typedef uint64_t        Elf64_Addr;
typedef uint64_t        Elf64_Off;
typedef uint32_t        Elf64_Word;
typedef uint64_t        Elf64_Xword;

// Source: https://refspecs.linuxfoundation.org/elf/gabi4+/ch4.sheader.html
typedef struct {
    Elf64_Word	sh_name;
    Elf64_Word	sh_type;
    Elf64_Xword	sh_flags;
    Elf64_Addr	sh_addr;
    Elf64_Off	sh_offset;
    Elf64_Xword	sh_size;
    Elf64_Word	sh_link;
    Elf64_Word	sh_info;
    Elf64_Xword	sh_addralign;
    Elf64_Xword	sh_entsize;
} Elf64_Shdr;
